(* Created with the Wolfram Language : www.wolfram.com *)
(C3*(-M\[Pi]^2 + s))/(4*fa*F\[Pi]) - (2*CS*\[CapitalDelta]I)/
  (3*fa*F\[Pi]*M\[Eta]^2 - 3*fa*F\[Pi]*M\[Pi]^2)
