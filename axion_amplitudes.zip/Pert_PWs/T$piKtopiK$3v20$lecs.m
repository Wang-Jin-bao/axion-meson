(* Created with the Wolfram Language : www.wolfram.com *)
(32*L6r*MK^2*M\[Pi]^2)/F\[Pi]^4 + (16*L8r*MK^2*M\[Pi]^2)/F\[Pi]^4 + 
 (4*L5r*M\[Pi]^2*(-MK^2 + M\[Pi]^2 - s))/F\[Pi]^4 - 
 (4*L4r*(MK^6 - MK^4*(M\[Pi]^2 + 2*s) + (M\[Pi]^3 - M\[Pi]*s)^2 + 
    MK^2*(-M\[Pi]^4 + 4*M\[Pi]^2*s + s^2)))/(F\[Pi]^4*s) + 
 (4*L2r*(MK^8 - MK^6*(4*M\[Pi]^2 + s) - MK^2*(M\[Pi]^2 - s)^2*
     (4*M\[Pi]^2 + 7*s) + MK^4*(6*M\[Pi]^4 + M\[Pi]^2*s + 3*s^2) + 
    (M\[Pi]^2 - s)^2*(M\[Pi]^4 + M\[Pi]^2*s + 4*s^2)))/(3*F\[Pi]^4*s^2) + 
 (8*L1r*(MK^8 - MK^6*(4*M\[Pi]^2 + s) + MK^4*M\[Pi]^2*(6*M\[Pi]^2 + s) + 
    (M\[Pi]^2 - s)^2*(M\[Pi]^4 + M\[Pi]^2*s + s^2) + 
    MK^2*(-4*M\[Pi]^6 + M\[Pi]^4*s + 4*M\[Pi]^2*s^2 - s^3)))/
  (3*F\[Pi]^4*s^2) + (4*L3r*(MK^8 - MK^6*(4*M\[Pi]^2 + s) + 
    MK^4*M\[Pi]^2*(6*M\[Pi]^2 + s) + (M\[Pi]^2 - s)^2*
     (M\[Pi]^4 + M\[Pi]^2*s + s^2) + MK^2*(-4*M\[Pi]^6 + M\[Pi]^4*s + 
      4*M\[Pi]^2*s^2 - s^3)))/(3*F\[Pi]^4*s^2)
