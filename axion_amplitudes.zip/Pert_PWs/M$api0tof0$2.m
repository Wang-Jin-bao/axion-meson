(* Created with the Wolfram Language : www.wolfram.com *)
{{(C3*(M\[Pi]^2 - s))/(Sqrt[6]*fa*F\[Pi]) - (5*Sqrt[2/3]*CS*\[CapitalDelta]I)/
    (3*fa*F\[Pi]*M\[Eta]^2 - 3*fa*F\[Pi]*M\[Pi]^2)}, 
 {(C3*(M\[Pi]^2 - s))/(4*Sqrt[2]*fa*F\[Pi]) + (Sqrt[2]*CS*\[CapitalDelta]I)/
    (3*fa*F\[Pi]*M\[Eta]^2 - 3*fa*F\[Pi]*M\[Pi]^2) + 
   (Sqrt[3/2]*C8*(M\[Pi]^2 - s)*\[CapitalDelta]I)/
    (4*fa*F\[Pi]*(M\[Eta]^2 - M\[Pi]^2))}}
