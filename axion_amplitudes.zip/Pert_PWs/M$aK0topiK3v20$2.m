(* Created with the Wolfram Language : www.wolfram.com *)
-((Sqrt[2/3]*CS*\[CapitalDelta]I)/(3*fa*F\[Pi]*M\[Eta]^2 - 
    3*fa*F\[Pi]*M\[Pi]^2)) + 
 C8*(-1/8*((MK0^2 - MKc^2)*(-MK0^2 + s))/(Sqrt[2]*fa*F\[Pi]*s) + 
   ((MK0^2 - s)*(-MK0^2 + M\[Pi]^2 + s)*\[CapitalDelta]I)/
    (8*Sqrt[2]*fa*F\[Pi]*(M\[Eta]^2 - M\[Pi]^2)*s)) + 
 C3*(-1/8*((MK0^2 - MKc^2 - 4*s)*(MK0^2 - s))/(Sqrt[6]*fa*F\[Pi]*s) - 
   ((MK0^2 - s)*(-MK0^2 + M\[Pi]^2 + s)*\[CapitalDelta]I)/
    (8*Sqrt[6]*fa*F\[Pi]*(M\[Eta]^2 - M\[Pi]^2)*s))
