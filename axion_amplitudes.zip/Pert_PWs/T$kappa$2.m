(* Created with the Wolfram Language : www.wolfram.com *)
{{-1/8*(3*MK^4 + 3*M\[Pi]^4 + 2*M\[Pi]^2*s - 5*s^2 + 
     MK^2*(-6*M\[Pi]^2 + 2*s))/(F\[Pi]^2*s), 
  (9*MK^4 + M\[Eta]^2*(9*M\[Pi]^2 - 3*s) - 
    MK^2*(9*M\[Eta]^2 + 9*M\[Pi]^2 + 2*s) + s*(-7*M\[Pi]^2 + 9*s))/
   (24*F\[Pi]^2*s)}, {(9*MK^4 + M\[Eta]^2*(9*M\[Pi]^2 - 3*s) - 
    MK^2*(9*M\[Eta]^2 + 9*M\[Pi]^2 + 2*s) + s*(-7*M\[Pi]^2 + 9*s))/
   (24*F\[Pi]^2*s), -1/24*(9*MK^4 + 9*M\[Eta]^4 - 6*M\[Eta]^2*s - 
     18*MK^2*(M\[Eta]^2 + s) + s*(4*M\[Pi]^2 + 9*s))/(F\[Pi]^2*s)}}
