(* Created with the Wolfram Language : www.wolfram.com *)
(C3*(M\[Pi]^2 - s))/(2*Sqrt[3]*fa*F\[Pi]) + (4*CS*\[CapitalDelta]I)/
  (Sqrt[3]*(3*fa*F\[Pi]*M\[Eta]^2 - 3*fa*F\[Pi]*M\[Pi]^2))
