(* Created with the Wolfram Language : www.wolfram.com *)
-1/2*(-2*M\[Pi]^2 + s)/F\[Pi]^2
