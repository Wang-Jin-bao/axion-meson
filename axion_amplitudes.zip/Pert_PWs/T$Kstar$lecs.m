(* Created with the Wolfram Language : www.wolfram.com *)
{{(L5r*M\[Pi]^2*(MK^4 + (M\[Pi]^2 - s)^2 - 2*MK^2*(M\[Pi]^2 + s)))/
    (F\[Pi]^4*s) + (4*L4r*(MK^2 + M\[Pi]^2)*(MK^4 + (M\[Pi]^2 - s)^2 - 
      2*MK^2*(M\[Pi]^2 + s)))/(3*F\[Pi]^4*s) - 
   (2*L2r*(MK^4 - 2*MK^2*M\[Pi]^2 + M\[Pi]^4 - s^2)*
     (MK^4 + (M\[Pi]^2 - s)^2 - 2*MK^2*(M\[Pi]^2 + s)))/(3*F\[Pi]^4*s^2) - 
   (4*L1r*(MK^4 - 2*MK^2*M\[Pi]^2 + M\[Pi]^4 + s^2)*
     (MK^4 + (M\[Pi]^2 - s)^2 - 2*MK^2*(M\[Pi]^2 + s)))/(3*F\[Pi]^4*s^2) - 
   (L3r*(MK^4 - 2*MK^2*M\[Pi]^2 + M\[Pi]^4 + 3*s^2)*
     (MK^4 + (M\[Pi]^2 - s)^2 - 2*MK^2*(M\[Pi]^2 + s)))/(6*F\[Pi]^4*s^2), 
  (-((L5r*M\[Pi]^2)/(F\[Pi]^4*s)) + 
    (L3r*(MK^4 + M\[Eta]^2*M\[Pi]^2 - MK^2*(M\[Eta]^2 + M\[Pi]^2) + 3*s^2))/
     (6*F\[Pi]^4*s^2))*RSqrt[MK^4 + (M\[Eta]^2 - s)^2 - 
     2*MK^2*(M\[Eta]^2 + s)]*RSqrt[MK^4 + (M\[Pi]^2 - s)^2 - 
     2*MK^2*(M\[Pi]^2 + s)]}, 
 {(-((L5r*M\[Pi]^2)/(F\[Pi]^4*s)) + 
    (L3r*(MK^4 + M\[Eta]^2*M\[Pi]^2 - MK^2*(M\[Eta]^2 + M\[Pi]^2) + 3*s^2))/
     (6*F\[Pi]^4*s^2))*RSqrt[MK^4 + (M\[Eta]^2 - s)^2 - 
     2*MK^2*(M\[Eta]^2 + s)]*RSqrt[MK^4 + (M\[Pi]^2 - s)^2 - 
     2*MK^2*(M\[Pi]^2 + s)], 
  (L5r*M\[Pi]^2*(MK^4 + (M\[Eta]^2 - s)^2 - 2*MK^2*(M\[Eta]^2 + s)))/
    (F\[Pi]^4*s) - (4*L4r*(-7*MK^2 + M\[Pi]^2)*(MK^4 + (M\[Eta]^2 - s)^2 - 
      2*MK^2*(M\[Eta]^2 + s)))/(9*F\[Pi]^4*s) - 
   (2*L2r*(MK^4 - 2*MK^2*M\[Eta]^2 + M\[Eta]^4 - s^2)*
     (MK^4 + (M\[Eta]^2 - s)^2 - 2*MK^2*(M\[Eta]^2 + s)))/(3*F\[Pi]^4*s^2) - 
   (4*L1r*(MK^4 - 2*MK^2*M\[Eta]^2 + M\[Eta]^4 + s^2)*
     (MK^4 + (M\[Eta]^2 - s)^2 - 2*MK^2*(M\[Eta]^2 + s)))/(3*F\[Pi]^4*s^2) - 
   (L3r*(11*MK^4 - 22*MK^2*M\[Eta]^2 + 11*M\[Eta]^4 + 9*s^2)*
     (MK^4 + (M\[Eta]^2 - s)^2 - 2*MK^2*(M\[Eta]^2 + s)))/(18*F\[Pi]^4*s^2)}}
