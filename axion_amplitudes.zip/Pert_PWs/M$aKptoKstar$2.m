(* Created with the Wolfram Language : www.wolfram.com *)
{{RSqrt[(MKc^2 - s)^2]*((-1/24*C3/(Sqrt[3]*fa*F\[Pi]*s) - 
      C8/(24*fa*F\[Pi]*s))*RSqrt[MK0^4 + (M\[Pi]^2 - s)^2 - 
       2*MK0^2*(M\[Pi]^2 + s)] + 
    (C8*(-1/48*1/(fa*F\[Pi]*s) - \[CapitalDelta]I/(48*fa*F\[Pi]*M\[Eta]^2*s - 
          48*fa*F\[Pi]*M\[Pi]^2*s)) + C3*(-1/48*1/(Sqrt[3]*fa*F\[Pi]*s) - 
        \[CapitalDelta]I/(Sqrt[3]*(48*fa*F\[Pi]*M\[Eta]^2*s - 
           48*fa*F\[Pi]*M\[Pi]^2*s))))*RSqrt[MKc^4 + (M\[Pi]^2 - s)^2 - 
       2*MKc^2*(M\[Pi]^2 + s)])}, 
 {(C8*(1/(16*fa*F\[Pi]*s) - \[CapitalDelta]I/(48*fa*F\[Pi]*M\[Eta]^2*s - 
        48*fa*F\[Pi]*M\[Pi]^2*s)) + C3*(1/(16*Sqrt[3]*fa*F\[Pi]*s) - 
      \[CapitalDelta]I/(Sqrt[3]*(48*fa*F\[Pi]*M\[Eta]^2*s - 
         48*fa*F\[Pi]*M\[Pi]^2*s))))*RSqrt[(MKc^2 - s)^2]*
   RSqrt[MKc^4 + (M\[Eta]^2 - s)^2 - 2*MKc^2*(M\[Eta]^2 + s)]}}
