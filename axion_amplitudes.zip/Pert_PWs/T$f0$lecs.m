(* Created with the Wolfram Language : www.wolfram.com *)
{{(40*(2*L6r + L8r)*M\[Pi]^4)/F\[Pi]^4 + (16*L4r*M\[Pi]^2*(-3*M\[Pi]^2 + s))/
    F\[Pi]^4 + (8*L5r*M\[Pi]^2*(-3*M\[Pi]^2 + s))/F\[Pi]^4 + 
   (4*L2r*(28*M\[Pi]^4 - 20*M\[Pi]^2*s + 7*s^2))/(3*F\[Pi]^4) + 
   (4*L1r*(44*M\[Pi]^4 - 40*M\[Pi]^2*s + 11*s^2))/(3*F\[Pi]^4) + 
   (L3r*(88*M\[Pi]^4 - 80*M\[Pi]^2*s + 22*s^2))/(3*F\[Pi]^4), 
  (16*Sqrt[3]*(2*L6r + L8r)*MK^2*M\[Pi]^2)/F\[Pi]^4 - 
   (2*Sqrt[3]*L5r*M\[Pi]^2*(4*MK^2 - s))/F\[Pi]^4 - 
   (8*Sqrt[3]*L1r*(2*MK^2 - s)*(-2*M\[Pi]^2 + s))/F\[Pi]^4 - 
   (8*Sqrt[3]*L4r*(MK^2*(4*M\[Pi]^2 - s) - M\[Pi]^2*s))/F\[Pi]^4 + 
   (8*L2r*(MK^2*(4*M\[Pi]^2 - s) + s*(-M\[Pi]^2 + s)))/(Sqrt[3]*F\[Pi]^4) + 
   (2*L3r*(MK^2*(16*M\[Pi]^2 - 7*s) + s*(-7*M\[Pi]^2 + 4*s)))/
    (Sqrt[3]*F\[Pi]^4)}, {(16*Sqrt[3]*(2*L6r + L8r)*MK^2*M\[Pi]^2)/F\[Pi]^4 - 
   (2*Sqrt[3]*L5r*M\[Pi]^2*(4*MK^2 - s))/F\[Pi]^4 - 
   (8*Sqrt[3]*L1r*(2*MK^2 - s)*(-2*M\[Pi]^2 + s))/F\[Pi]^4 - 
   (8*Sqrt[3]*L4r*(MK^2*(4*M\[Pi]^2 - s) - M\[Pi]^2*s))/F\[Pi]^4 + 
   (8*L2r*(MK^2*(4*M\[Pi]^2 - s) + s*(-M\[Pi]^2 + s)))/(Sqrt[3]*F\[Pi]^4) + 
   (2*L3r*(MK^2*(16*M\[Pi]^2 - 7*s) + s*(-7*M\[Pi]^2 + 4*s)))/
    (Sqrt[3]*F\[Pi]^4), (48*(2*L6r + L8r)*MK^4)/F\[Pi]^4 - 
   (8*L4r*(8*MK^4 - 3*MK^2*s))/F\[Pi]^4 + (L5r*(-24*MK^4 + 6*M\[Pi]^2*s))/
    F\[Pi]^4 + (4*L3r*(8*MK^4 - 7*MK^2*s + 2*s^2))/F\[Pi]^4 + 
   (8*L2r*(16*MK^4 - 11*MK^2*s + 4*s^2))/(3*F\[Pi]^4) + 
   (8*L1r*(28*MK^4 - 26*MK^2*s + 7*s^2))/(3*F\[Pi]^4)}}
