(* Created with the Wolfram Language : www.wolfram.com *)
(32*L6r*M\[Pi]^4)/F\[Pi]^4 + (16*L8r*M\[Pi]^4)/F\[Pi]^4 - 
 (8*L4r*M\[Pi]^2*s)/F\[Pi]^4 - (4*L5r*M\[Pi]^2*s)/F\[Pi]^4 + 
 (8*L1r*(4*M\[Pi]^4 - 2*M\[Pi]^2*s + s^2))/(3*F\[Pi]^4) + 
 (4*L3r*(4*M\[Pi]^4 - 2*M\[Pi]^2*s + s^2))/(3*F\[Pi]^4) + 
 (8*L2r*(8*M\[Pi]^4 - 7*M\[Pi]^2*s + 2*s^2))/(3*F\[Pi]^4)
