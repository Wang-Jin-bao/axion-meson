(* Created with the Wolfram Language : www.wolfram.com *)
{{(MK^4 + (M\[Pi]^2 - s)^2 - 2*MK^2*(M\[Pi]^2 + s))/(8*F\[Pi]^2*s), 
  -1/8*(RSqrt[MK^4 + (M\[Eta]^2 - s)^2 - 2*MK^2*(M\[Eta]^2 + s)]*
     RSqrt[MK^4 + (M\[Pi]^2 - s)^2 - 2*MK^2*(M\[Pi]^2 + s)])/(F\[Pi]^2*s)}, 
 {-1/8*(RSqrt[MK^4 + (M\[Eta]^2 - s)^2 - 2*MK^2*(M\[Eta]^2 + s)]*
     RSqrt[MK^4 + (M\[Pi]^2 - s)^2 - 2*MK^2*(M\[Pi]^2 + s)])/(F\[Pi]^2*s), 
  (MK^4 + (M\[Eta]^2 - s)^2 - 2*MK^2*(M\[Eta]^2 + s))/(8*F\[Pi]^2*s)}}
