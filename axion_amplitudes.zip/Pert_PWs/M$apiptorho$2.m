(* Created with the Wolfram Language : www.wolfram.com *)
{{(C3*RSqrt[(M\[Pi]^2 - s)^2]*RSqrt[s*(-4*M\[Pi]^2 + s)])/(12*fa*F\[Pi]*s)}, 
 {(C3*RSqrt[(M\[Pi]^2 - s)^2]*RSqrt[MK0^4 + (MKc^2 - s)^2 - 
      2*MK0^2*(MKc^2 + s)])/(12*Sqrt[2]*fa*F\[Pi]*s)}}
