(* Created with the Wolfram Language : www.wolfram.com *)
(MK^2 + M\[Pi]^2 - s)/(2*F\[Pi]^2)
