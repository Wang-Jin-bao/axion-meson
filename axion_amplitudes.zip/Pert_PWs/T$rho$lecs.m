(* Created with the Wolfram Language : www.wolfram.com *)
{{(-2*(4*M\[Pi]^2 - s)*(2*(2*L4r + L5r)*M\[Pi]^2 + (-2*L1r + L2r - L3r)*s))/
   (3*F\[Pi]^4), -1/3*(Sqrt[2]*(-2*L5r*M\[Pi]^2 + L3r*s)*
     RSqrt[s*(-4*MK^2 + s)]*RSqrt[s*(-4*M\[Pi]^2 + s)])/(F\[Pi]^4*s)}, 
 {-1/3*(Sqrt[2]*(-2*L5r*M\[Pi]^2 + L3r*s)*RSqrt[s*(-4*MK^2 + s)]*
     RSqrt[s*(-4*M\[Pi]^2 + s)])/(F\[Pi]^4*s), 
  -1/3*((4*MK^2 - s)*(8*L4r*MK^2 + 2*L5r*M\[Pi]^2 - (4*L1r - 2*L2r + L3r)*s))/
    F\[Pi]^4}}
