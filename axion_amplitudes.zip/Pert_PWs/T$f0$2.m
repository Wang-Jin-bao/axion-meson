(* Created with the Wolfram Language : www.wolfram.com *)
{{-1/2*(M\[Pi]^2 - 2*s)/F\[Pi]^2, (Sqrt[3]*s)/(4*F\[Pi]^2)}, 
 {(Sqrt[3]*s)/(4*F\[Pi]^2), (3*s)/(4*F\[Pi]^2)}}
