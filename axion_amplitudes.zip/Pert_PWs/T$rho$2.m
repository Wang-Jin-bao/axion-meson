(* Created with the Wolfram Language : www.wolfram.com *)
{{(-4*M\[Pi]^2 + s)/(6*F\[Pi]^2), 
  (RSqrt[s*(-4*MK^2 + s)]*RSqrt[s*(-4*M\[Pi]^2 + s)])/
   (6*Sqrt[2]*F\[Pi]^2*s)}, 
 {(RSqrt[s*(-4*MK^2 + s)]*RSqrt[s*(-4*M\[Pi]^2 + s)])/(6*Sqrt[2]*F\[Pi]^2*s), 
  (-4*MK^2 + s)/(12*F\[Pi]^2)}}
