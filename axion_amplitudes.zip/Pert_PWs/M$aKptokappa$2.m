(* Created with the Wolfram Language : www.wolfram.com *)
{{CS*(-(Sqrt[3]/(fa*F\[Pi])) + \[CapitalDelta]I/
      (Sqrt[3]*(3*fa*F\[Pi]*M\[Eta]^2 - 3*fa*F\[Pi]*M\[Pi]^2))) + 
   C8*(((MKc^2 - s)*(2*MK0^2 + MKc^2 - 3*(M\[Pi]^2 + s)))/(16*fa*F\[Pi]*s) - 
     ((MKc^2 - s)*(-MKc^2 + M\[Pi]^2 + s)*\[CapitalDelta]I)/
      (16*fa*F\[Pi]*(M\[Eta]^2 - M\[Pi]^2)*s)) + 
   C3*(((MKc^2 - s)*(2*MK0^2 + MKc^2 - 3*M\[Pi]^2 + 5*s))/
      (16*Sqrt[3]*fa*F\[Pi]*s) - ((MKc^2 - s)*(-MKc^2 + M\[Pi]^2 + s)*
       \[CapitalDelta]I)/(16*Sqrt[3]*fa*F\[Pi]*(M\[Eta]^2 - M\[Pi]^2)*s))}, 
 {CS*(-(1/(Sqrt[3]*fa*F\[Pi])) - \[CapitalDelta]I/
      (Sqrt[3]*(fa*F\[Pi]*M\[Eta]^2 - fa*F\[Pi]*M\[Pi]^2))) + 
   C8*((3*(MKc^2 - s)*(-MKc^2 + M\[Eta]^2 + s))/(16*fa*F\[Pi]*s) - 
     ((MKc^2 - s)*(-MKc^2 + M\[Eta]^2 + s)*\[CapitalDelta]I)/
      (16*fa*F\[Pi]*(M\[Eta]^2 - M\[Pi]^2)*s)) + 
   C3*(-1/16*(Sqrt[3]*(MKc^2 - s)*(MKc^2 - M\[Eta]^2 - s))/(fa*F\[Pi]*s) - 
     ((MKc^2 - s)*(-MKc^2 + M\[Eta]^2 + s)*\[CapitalDelta]I)/
      (16*Sqrt[3]*fa*F\[Pi]*(M\[Eta]^2 - M\[Pi]^2)*s))}}
