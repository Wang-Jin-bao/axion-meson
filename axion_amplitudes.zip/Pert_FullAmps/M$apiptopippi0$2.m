(* Created with the Wolfram Language : www.wolfram.com *)
-1/2*(C3*M\[Pi]^2)/(fa*F\[Pi]) + (C3*u)/(2*fa*F\[Pi]) - 
 (2*CS*X\[Pi]\[Eta]*\[CapitalDelta]I)/(Sqrt[3]*fa*F\[Pi])
