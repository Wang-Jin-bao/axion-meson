(* Created with the Wolfram Language : www.wolfram.com *)
(-2*Sqrt[3]*CS*X\[Pi]\[Eta]*\[CapitalDelta]I)/(fa*F\[Pi])
