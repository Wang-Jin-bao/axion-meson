(* Created with the Wolfram Language : www.wolfram.com *)
-(CS/(fa*F\[Pi])) - (C3*M\[Pi]^2)/(8*fa*F\[Pi]) + 
 (Sqrt[3]*C8*M\[Pi]^2)/(8*fa*F\[Pi]) + (C3*s)/(8*fa*F\[Pi]) - 
 (Sqrt[3]*C8*s)/(8*fa*F\[Pi]) + (CS*X\[Pi]\[Eta]*\[CapitalDelta]I)/
  (Sqrt[3]*fa*F\[Pi]) - (Sqrt[3]*C3*M\[Pi]^2*X\[Pi]\[Eta]*\[CapitalDelta]I)/
  (8*fa*F\[Pi]) + (3*C8*M\[Pi]^2*X\[Pi]\[Eta]*\[CapitalDelta]I)/
  (8*fa*F\[Pi]) + (Sqrt[3]*C3*s*X\[Pi]\[Eta]*\[CapitalDelta]I)/
  (8*fa*F\[Pi]) - (3*C8*s*X\[Pi]\[Eta]*\[CapitalDelta]I)/(8*fa*F\[Pi])
