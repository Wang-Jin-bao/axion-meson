(* Created with the Wolfram Language : www.wolfram.com *)
(Sqrt[2]*CS)/(fa*F\[Pi]) + (C3*MK0^2)/(4*Sqrt[2]*fa*F\[Pi]) - 
 (C3*MKc^2)/(4*Sqrt[2]*fa*F\[Pi]) - (Sqrt[3/2]*C8*M\[Pi]^2)/(4*fa*F\[Pi]) + 
 (Sqrt[3/2]*C8*s)/(4*fa*F\[Pi]) + (C3*t)/(4*Sqrt[2]*fa*F\[Pi]) - 
 (C3*u)/(4*Sqrt[2]*fa*F\[Pi])
